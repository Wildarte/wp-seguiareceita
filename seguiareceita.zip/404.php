<?php get_header(); ?>

<main>
    <section class="container">
        <h3 style="width: 100%; text-align: center; margin: 100px auto ;">Página não encontrada... :(</h3>
    </section>
</main>

<?php get_footer(); ?>